import React from "react";
import AdminHeader from "../Admin/adminheader";
import SalesAndBilling from "./sales";

function Billing () {
    return(
        <div>
            <AdminHeader />
            <SalesAndBilling />
        </div>
    )
}
export default Billing;