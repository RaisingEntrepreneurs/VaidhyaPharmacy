// App.js
import React, { useState } from 'react';
import { QrReader } from 'react-qr-reader';

const Barreader = () => {
  const [barcodeData, setBarcodeData] = useState('');

  const handleScan = (data) => {
    if (data) {
      setBarcodeData(data);
    }
  };

  const handleError = (err) => {
    console.error(err);
  };

  return (
    <div>
      <h1>Pharmacy Inventory Management System</h1>
      <QrReader
        delay={300}
        onError={handleError}
        onScan={handleScan}
        style={{ width: '100%' }}
      />
      <h2>Scanned Barcode: {barcodeData}</h2>
    </div>
  );
};

export default Barreader;
