import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import Header from './Homepage/Header';
import Billing from './Sales/sales';
import Inventory from './Product/product';
import Dashboard from './audits/Inventory';
import Login from './Homepage/Homepage';
import Barreader from './bar_reader';

function Pharmacy() {
  return (
   
      <Router>
        <header></header>
        <div>
          
          
            
          <Barreader></Barreader>
        </div>
      </Router>
    
    
  );
}

export default Pharmacy;
