import React, { useState, useEffect } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import axios from 'axios';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Modal,
  Paper,
  TextField,
  Typography,
  InputAdornment,
  Grid
} from '@mui/material';

function ProductTable({ products, onDelete, onUpdate }) {
  const [searchResults, setSearchResults] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [updatedProductData, setUpdatedProductData] = useState({
    product_id: '',
    product_name: '',
    category: '',
    manufacturer: '',
    batch_number: '',
    expiration_date: '',
    purchase_price: '',
    selling_price: '',
    stock_quantity: '',
    minimum_stock_level: '',
    maximum_stock_level: '',
    reorder_level: '',
    location: '',
    gst_rate: '',
    package_type: '',
    units_per_package: '',
    schedule_category: '',
    creat_tmst: ''
  });

  useEffect(() => {
    // Fetch initial inventory data
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    try {
      const response = await axios.get('http://127.0.0.1:5000/api/inventory');
      setSearchResults(response.data);
    } catch (error) {
      console.error('Error fetching inventory:', error);
    }
  };

  const handleSearchChange = async (event) => {
    setSearchTerm(event.target.value);
    try {
      const response = await axios.get(`http://127.0.0.1:5000/api/inventory/${event.target.value}`);
      setSearchResults(response.data);
      // If no results found, enable adding new drug
      if (response.data.length === 0) {
        setShowUpdateModal(true);
        setSelectedProduct(null);
        setUpdatedProductData({
          product_name: event.target.value,
          category: '',
          manufacturer: '',
          batch_number: '',
          expiration_date: '',
          purchase_price: '',
          selling_price: '',
          stock_quantity: '',
          minimum_stock_level: '',
          maximum_stock_level: '',
          reorder_level: '',
          location: '',
          gst_rate: '',
          package_type: '',
          units_per_package: '',
          schedule_category: '',
          creat_tmst: ''
        });
      }
    } catch (error) {
      console.error('Error searching products:', error);
    }
  };

  const handleUpdateClick = (product) => {
    setSelectedProduct(product);
    setUpdatedProductData({ ...product });
    setShowUpdateModal(true);
  };

  const handleSaveUpdate = () => {
    onUpdate(selectedProduct.product_id, updatedProductData);
    setShowUpdateModal(false);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUpdatedProductData({ ...updatedProductData, [name]: value });
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div style={{ marginBottom: '250px' }}>
      <h3 style={{ color: '#18B7BE', fontSize: '24px', marginBottom: '10px' }}>Search Medicine</h3>
      <TextField
        fullWidth
        placeholder="Search by Medicine Name"
        value={searchTerm}
        onChange={handleSearchChange}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon />
            </InputAdornment>
          ),
        }}
      />
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ color: '#18B7BE' }}>Product ID</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Product Name</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Category</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Manufacturer</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Batch Number</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Expiration Date</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Purchase Price</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Selling Price</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Stock Quantity</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Minimum Stock Level</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Maximum Stock Level</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Reorder Level</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Location</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>GST Rate</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Package Type</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Units per Package</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Schedule Category</TableCell>
              <TableCell sx={{ color: '#18B7BE' }}>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {searchTerm
              ? searchResults.map((product) => (
                <TableRow key={product.product_id}>
                  <TableCell>{product.product_id}</TableCell>
                  <TableCell>{product.product_name}</TableCell>
                  <TableCell>{product.category}</TableCell>
                  <TableCell>{product.manufacturer}</TableCell>
                  <TableCell>{product.batch_number}</TableCell>
                  <TableCell>{product.expiration_date ? formatDate(product.expiration_date) : ''}</TableCell>
                  <TableCell>{product.purchase_price}</TableCell>
                  <TableCell>{product.selling_price}</TableCell>
                  <TableCell>{product.stock_quantity}</TableCell>
                  <TableCell>{product.minimum_stock_level}</TableCell>
                  <TableCell>{product.maximum_stock_level}</TableCell>
                  <TableCell>{product.reorder_level}</TableCell>
                  <TableCell>{product.location}</TableCell>
                  <TableCell>{product.gst_rate}</TableCell>
                  <TableCell>{product.package_type}</TableCell>
                  <TableCell>{product.units_per_package}</TableCell>
                  <TableCell>{product.schedule_category}</TableCell>

                  <TableCell>
                    <Button onClick={() => handleUpdateClick(product)} style={{ backgroundColor: '#178CA4', color: 'white' }}>Update</Button>
                    <Button onClick={() => onDelete(product.product_id)} style={{ backgroundColor: '#178CA4', color: 'white' }}>Delete</Button>
                  </TableCell>
                </TableRow>
              ))
              : products.map((product) => (
                <TableRow key={product.product_id}>
                  <TableCell>{product.product_id}</TableCell>
                  <TableCell>{product.product_name}</TableCell>
                  <TableCell>{product.category}</TableCell>
                  <TableCell>{product.manufacturer}</TableCell>
                  <TableCell>{product.batch_number}</TableCell>
                  <TableCell>{product.expiration_date ? formatDate(product.expiration_date) : ''}</TableCell>
                  <TableCell>{product.purchase_price}</TableCell>
                  <TableCell>{product.selling_price}</TableCell>
                  <TableCell>{product.stock_quantity}</TableCell>
                  <TableCell>{product.minimum_stock_level}</TableCell>
                  <TableCell>{product.maximum_stock_level}</TableCell>
                  <TableCell>{product.reorder_level}</TableCell>
                  <TableCell>{product.location}</TableCell>
                  <TableCell>{product.gst_rate}</TableCell>
                  <TableCell>{product.package_type}</TableCell>
                  <TableCell>{product.units_per_package}</TableCell>
                  <TableCell>{product.schedule_category}</TableCell>

                  <TableCell>
                    <Button variant="contained" color="primary" className="add-button" style={{ backgroundColor: '#55c2da', marginRight: '10px' }} onClick={() => handleUpdateClick(product)}>Update</Button>
                    <Button variant="contained" color="primary" className="add-button" style={{ backgroundColor: '#55c2da' }} onClick={() => onDelete(product.product_id)}>Delete</Button>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Modal open={showUpdateModal} onClose={() => setShowUpdateModal(false)} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Paper style={{ padding: '20px', maxWidth: '1600px', width: '100%', maxHeight: '800px' }}>
          <Typography variant="h6" style={{ marginBottom: '20px' }}>Update Product</Typography>
          <Grid container spacing={4}>
            <Grid item sm={2} >
              <TextField
                label="Product ID"
                name="product_id"
                value={updatedProductData.product_id}
                onChange={handleInputChange}
                disabled
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Product Name"
                name="product_name"
                value={updatedProductData.product_name}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Category"
                name="category"
                value={updatedProductData.category}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Manufacturer"
                name="manufacturer"
                value={updatedProductData.manufacturer}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Batch Number"
                name="batch_number"
                value={updatedProductData.batch_number}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Expiration Date"
                name="expiration_date"
                type="date"
                value={updatedProductData.expiration_date}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Purchase Price"
                name="purchase_price"
                value={updatedProductData.purchase_price}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Selling Price"
                name="selling_price"
                value={updatedProductData.selling_price}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Stock Quantity"
                name="stock_quantity"
                value={updatedProductData.stock_quantity}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Minimum Stock Level"
                name="minimum_stock_level"
                value={updatedProductData.minimum_stock_level}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Maximum Stock Level"
                name="maximum_stock_level"
                value={updatedProductData.maximum_stock_level}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Reorder Level"
                name="reorder_level"
                value={updatedProductData.reorder_level}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Location"
                name="location"
                value={updatedProductData.location}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="GST Rate"
                name="gst_rate"
                value={updatedProductData.gst_rate}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Package Type"
                name="package_type"
                value={updatedProductData.package_type}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Units per Package"
                name="units_per_package"
                value={updatedProductData.units_per_package}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Schedule Category"
                name="schedule_category"
                value={updatedProductData.schedule_category}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <TextField
                label="Creation Timestamp"
                name="creat_tmst"
                value={updatedProductData.creat_tmst}
                onChange={handleInputChange}
              /></Grid>
            <Grid item sm={2} >
              <Button onClick={handleSaveUpdate} type="submit" variant="contained" color="primary" className="add-button" style={{ backgroundColor: '#55c2da' }}>Save</Button></Grid>
            <Grid item sm={2} >
              <Button onClick={() => setShowUpdateModal(false)} type="submit" variant="contained" color="primary" className="add-button" style={{ backgroundColor: '#55c2da' }}>Cancel</Button>
            </Grid>
          </Grid>
        </Paper>
      </Modal>
    </div>
  );
}

export default ProductTable;
