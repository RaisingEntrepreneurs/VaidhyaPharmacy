import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductTable from './ProductTable';
import ProductForm from './ProductForm';
import Header from '../Homepage/Header';
import Adminheader from '../Admin/adminheader';
function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://127.0.0.1:5000/api/inventory');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleAddProduct = async productData => {
    console.log(productData)
    try {
      const response = await axios.post('http://127.0.0.1:5000/api/inventory', productData);
      setProducts(prevProducts => [...prevProducts, response.data]);
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const handleDeleteProduct = async productId => {
    try {
      await axios.delete(`http://127.0.0.1:5000/api/inventory/${productId}`);
      setProducts(prevProducts => prevProducts.filter(product => product.Product_id !== productId));
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  const handleUpdateProduct = async (productId, updatedProductData) => {
    try {
      await axios.put(`http://127.0.0.1:5000/api/inventory/${productId}`, updatedProductData);
      setProducts(prevProducts =>
        prevProducts.map(product =>
          product.Product_id === productId ? { ...product, ...updatedProductData } : product
        )
      );
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  return (
    <div>
    <Adminheader />
    
    <div style={{ paddingLeft: '20px' }}>
              
      <ProductForm onSubmit={handleAddProduct} />
      <ProductTable
        products={products}
        onDelete={handleDeleteProduct}
        onUpdate={handleUpdateProduct}
      />
    </div>
    </div>
  );
}

export default Products;
