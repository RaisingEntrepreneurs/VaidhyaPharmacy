import React, { useState, useEffect,useRef } from 'react';
import axios from 'axios';
import { TextField, Button, Grid } from '@mui/material';

function ProductForm({ onSubmit }) {
  const [inventory, setInventory] = useState([]);
const fileInputRef = useRef(null);
  /////CSV handling /////
const handleFileUpload = async event => {
  const file = event.target.files[0];
  if (file) {
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await axios.post('http://localhost:5000/api/uploadinventory', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      console.log('File uploaded successfully:', response.data);
      // Refresh inventory data after uploading
      fetchInventory();
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  }
};

const handleImportInventory = () => {
  fileInputRef.current.click(); // Trigger file input click event
};

const handleExportInventory = () => {
  const inventoryCSV = convertInventoryToCSV(inventory);

  // Create a Blob object containing the CSV data
  const blob = new Blob([inventoryCSV], { type: 'text/csv' });

  // Create a link element to trigger the download
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'inventory.csv';

  // Simulate a click on the link to start the download
  document.body.appendChild(link);
  link.click();

  // Clean up
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);
};

const convertInventoryToCSV = (data) => {
  // Your CSV conversion logic
  // You need to convert your inventory data array to a CSV string
  // For example, iterate over the inventory array and construct the CSV string
  // Each row of the CSV should represent an item in the inventory

  let csv = 'inventory_id,product_id,product_name,category,manufacturer,batch_number,expiration_date,purchase_price,selling_price,stock_quantity,minimum_stock_level,maximum_stock_level,reorder_level,location,gst_rate,package_type,units_per_package,schedule_category,creat_tmst\n';
  data.forEach(item => {
    csv += `${item.inventory_id},${item.product_id},${item.product_name},${item.category},${item.manufacturer},${item.batch_number},${item.expiration_date},${item.purchase_price},${item.selling_price},${item.stock_quantity},${item.minimum_stock_level},${item.maximum_stock_level},${item.reorder_level},${item.location},${item.gst_rate},${item.package_type},${item.units_per_package},${item.schedule_category},${item.creat_tmst}\n`;
  });

  return csv;
};
const fetchInventory = async () => {
  try {
    const response = await axios.get('http://localhost:5000/api/inventory');
    setInventory(response.data);
  } catch (error) {
    console.error('Error fetching inventory:', error);
  }
};

  const [productData, setProductData] = useState({
    Product_id: '',
    Product_name: '',
    Generic_name: '',
    Manufacturer: '',
    Dosage_form: '',
    Quali_in_stock: 0,
    Expiry_date: '',
    Price_per_unit: '',
    Category: '',
    Batch_number: '',
    Selling_price: '',
    Stock_quantity: '',
    Minimum_stock_level: '',
    Maximum_stock_level: '',
    Reorder_level: '',
    Location: '',
    Gst_rate: '',
    Package_type: '',
    Units_per_package: '',
    Schedule_category: ''
  });

  const handleChange = event => {
    const { name, value } = event.target;
    setProductData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = event => {
    event.preventDefault();
    onSubmit(productData);
    setProductData({
      Product_id: '',
      Product_name: '',
      Generic_name: '',
      Manufacturer: '',
      Dosage_form: '',
      Quali_in_stock: 0,
      Expiry_date: '',
      Price_per_unit: '',
      Category: '',
      Batch_number: '',
      Selling_price: '',
      Stock_quantity: '',
      Minimum_stock_level: '',
      Maximum_stock_level: '',
      Reorder_level: '',
      Location: '',
      Gst_rate: '',
      Package_type: '',
      Units_per_package: '',
      Schedule_category: ''
    });
  };

  return (
    <form onSubmit={handleSubmit} className="product-form">
  <div style={{ display: 'flex', alignItems: 'center' }}>
    <h3 style={{ color: '#18B7BE', fontSize: '24px', marginBottom: '10px' }}>Add Product</h3>
    <div style={{ flexGrow: 1 }}></div> {/* Spacer to push buttons to the right */}
    <div style={{ display: 'flex', marginTop: '10px' , marginBottom:'30px'}}>
      <Button
        variant="contained"
        color="primary"
        style={{ backgroundColor: '#178CA4', marginRight: '20px' }}
        onClick={handleImportInventory}
      >
        Import Inventory
      </Button>
      <input
        type="file"
        accept=".csv"
        ref={fileInputRef}
        style={{ display: 'none' }}
        onChange={handleFileUpload}
      />
      <Button
        variant="contained"
        color="primary"
        style={{ backgroundColor: '#178CA4', marginLeft: '10px' }}
        onClick={handleExportInventory}
      >
        Export Inventory
      </Button>
    </div>
    </div>
      
      <Grid container spacing={4}>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Product Id" name="Product_id" value={productData.Product_id} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Product Name" name="Product_name" value={productData.Product_name} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Generic Name" name="Generic_name" value={productData.Generic_name} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" name="Manufacturer" value={productData.Manufacturer} onChange={handleChange} label="Manufacturer" />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Dosage Form" name="Dosage_form" value={productData.Dosage_form} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" type="number" label="Quantity in Stock" name="Quali_in_stock" value={productData.Quali_in_stock} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" type="date" name="Expiry_date" value={productData.Expiry_date} onChange={handleChange} label="Expiry Date" InputLabelProps={{ shrink: true }} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Price Per Unit" name="Price_per_unit" value={productData.Price_per_unit} onChange={handleChange} />
        </Grid>
        {/* New Fields */}
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Category" name="Category" value={productData.Category} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Batch Number" name="Batch_number" value={productData.Batch_number} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Selling Price" name="Selling_price" value={productData.Selling_price} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Stock Quantity" name="Stock_quantity" value={productData.Stock_quantity} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Minimum Stock Level" name="Minimum_stock_level" value={productData.Minimum_stock_level} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Maximum Stock Level" name="Maximum_stock_level" value={productData.Maximum_stock_level} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Reorder Level" name="Reorder_level" value={productData.Reorder_level} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Location" name="Location" value={productData.Location} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="GST Rate" name="Gst_rate" value={productData.Gst_rate} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Package Type" name="Package_type" value={productData.Package_type} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Units per Package" name="Units_per_package" value={productData.Units_per_package} onChange={handleChange} />
        </Grid>
        <Grid item sm={2}>
          <TextField variant="outlined" size="medium" label="Schedule Category" name="Schedule_category" value={productData.Schedule_category} onChange={handleChange} />
        </Grid>
        {/* End of New Fields */}
        <Grid item sm={2}>
          <Button type="submit" variant="contained" color="primary" className="add-button" style={{ backgroundColor: '#178CA4' }}>Add</Button>
        </Grid>
      </Grid>
      <hr style={{ width: '100%', color: '#18B7BE', backgroundColor: '#18B7BE', height: '1px', border: 'none' }} />
    </form>
  );
}

export default ProductForm;
