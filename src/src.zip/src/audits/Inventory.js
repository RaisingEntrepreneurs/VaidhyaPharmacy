import React, { useState, useEffect } from 'react';
import { VictoryBar, VictoryChart, VictoryAxis, VictoryTheme } from 'victory';
import axios from 'axios';

import { aggregateSalesData } from './aggregate';

const InventoryChart = () => {
  const [totalSalesData, setTotalSalesData] = useState([]);
  const [totalInventoryData, setTotalInventoryData] = useState([]);
  const [reportType, setReportType] = useState('daily');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const salesResponse = await axios.get('http://localhost:5000/api/pharmacy_billing');
        const inventoryResponse = await axios.get('http://localhost:5000/api/inventory');

        const salesData = salesResponse.data;
        const inventoryData = inventoryResponse.data;

        // Process sales data to aggregate sales based on report type
        const aggregatedSalesData = aggregateSalesData(salesData, reportType);
        setTotalSalesData(aggregatedSalesData);

        // Set total inventory data
        setTotalInventoryData(inventoryData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [reportType]);

  return (
    <div>
      
       <div style={{ display: 'flex', alignItems: 'flex-start' ,marginLeft:'10px'}}>
      <div style ={{marginRight:'20px', marginBottom:'20px', marginTop:'20px'}}>
      <h2 style={{ color: '#18B7BE', fontSize: '24px', display: 'inline-block' }}>Total Sales per Product</h2>
      <div style={{ height: '400px', width: '600px' }}>
        <VictoryChart
          domainPadding={20}
          theme={VictoryTheme.material}
          width={600}
          height={400}
        >
          <VictoryAxis
            tickFormat={tick => tick}
            style={{
              tickLabels: { angle: -45, fontSize: 8, padding: 5 }
            }}
          />
          <VictoryAxis dependentAxis />
          <VictoryBar
            data={totalSalesData}
            x="product"
            y="totalSales"
            style={{ data: { fill: 'rgba(75, 192, 192, 0.7)' } }}
          />
        </VictoryChart>
      </div></div>
      <div>
      <h2 style={{ color: '#18B7BE', fontSize: '24px', display: 'inline-block', marginTop:'20px'}}>Total Inventory</h2>
      <div style={{ height: '400px', width: '600px' }}>
        <VictoryChart
          domainPadding={20}
          theme={VictoryTheme.material}
          width={600}
          height={400}
        >
          <VictoryAxis
            tickFormat={tick => tick}
            style={{
              tickLabels: { angle: -45, fontSize: 8, padding: 5 }
            }}
          />
          <VictoryAxis dependentAxis />
          <VictoryBar
            data={totalInventoryData}
            x="Product_name" // Change this to the correct key for product name in your inventory data
            y="Quali_in_stock" // Change this to the correct key for quantity in your inventory data
            style={{ data: { fill: 'rgba(192, 75, 75, 0.7)' } }}
          />
        </VictoryChart>
      </div></div>
      </div>
      <div>
        <label style={{ color: '#005493', fontSize: '16px', display: 'inline-block',marginRight:'10px' }}>Select Report Type:</label>
        <select value={reportType} onChange={(e) => setReportType(e.target.value)}>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
      </div>
      
    </div>
  );
};

export default InventoryChart;
