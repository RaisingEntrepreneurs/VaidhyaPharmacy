import React from "react";
import InventoryChart from "./Inventory";

import Adminheader from "../Admin/adminheader";;

function Dashboarda () {
    return(
    
        <div>
          <Adminheader/>
            <InventoryChart />
                
        </div>
    )
}
export default Dashboarda;