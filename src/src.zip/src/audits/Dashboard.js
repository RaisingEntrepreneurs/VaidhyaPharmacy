import React from "react";
import InventoryChart from "./Inventory";

import PharmaHeader from "../Homepage/pharmaheader";

function Dashboard () {
    return(
    
        <div>
          <PharmaHeader />
            <InventoryChart />
                
        </div>
    )
}
export default Dashboard;