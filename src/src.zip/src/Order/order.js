import React, { useState, useEffect } from 'react';
import Return from './return'; 
import Adminheader from '../Admin/adminheader';
import axios from 'axios';
import { Button, Grid, Typography, Table, TableHead, TableBody, TableRow, TableCell, Select, MenuItem, TextField } from '@mui/material';

const OrderManagement = () => {
  const [showNewOrder, setShowNewOrder] = useState(false);
  const [showReturnOrder, setShowReturnOrder] = useState(false);
  const [vendorOptions, setVendorOptions] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState('');
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [orders, setOrders] = useState([]);
  const [orderDetails, setOrderDetails] = useState([]);
  useEffect(() => {
    const fetchVendors = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/vendors');
        setVendorOptions(response.data);
      } catch (error) {
        console.error('Error fetching vendors:', error);
      }
    };

    fetchVendors();
  }, []);
  useEffect(() => {
    const fetchInventoryOrders = async () => {
      try {
        const inventoryResponse = await axios.get('http://localhost:5000/api/inventory_order');
        const inventoryOrders = inventoryResponse.data;
  
        const vendorResponse = await axios.get('http://localhost:5000/api/vendors');
        const vendors = vendorResponse.data;
        
        const updatedOrders = inventoryOrders.map(order => ({
          ...order,
          vendors
        }));
     console.log(updatedOrders);
        setOrders(updatedOrders);
  
        // Initialize order details state with default values for each order
        const initialOrderDetails = updatedOrders.map(vendors => ({
          quantity: '', // Initialize quantity to empty string
          selectedVendor: '' // Initialize selected vendor to empty string
        }));
       
        setOrderDetails(initialOrderDetails);
      } catch (error) {
        console.error('Error fetching inventory orders:', error);
      }
    };
  
    fetchInventoryOrders();
  }, []);
     
  const handleAddOrder = async (index) => {
    try {
      if (orders[index] && orders[index].product_name && orderDetails[index]) {
        const response = await axios.post('http://localhost:5000/api/orders', {
          user_id: 'user123',
          order_product: orders[index].product_name,
          order_quantity: orderDetails[index].quantity,
          vendor: orderDetails[index].selectedVendor, 
          order_status: 'pending'
        });
        console.log('Order created:', response.data);
      } else {
        console.error('Error creating order: Invalid order data', index, orders, orderDetails);
      }
    } catch (error) {
      console.error('Error creating order:', error.message);
    }
  };
  

  const handleQuantityChange = (index, value) => {
    const updatedOrderDetails = [...orderDetails];
    updatedOrderDetails[index].quantity = value;
    setOrderDetails(updatedOrderDetails);
  };
  const handleVendorChange = (index, value) => {
    const updatedOrderDetails = [...orderDetails];
    updatedOrderDetails[index].selectedVendor = value;
    setOrderDetails(updatedOrderDetails);
  };
  

  const handleProductNameChange = (event) => {
    setProductName(event.target.value);
  };

  const handleQuantityInputChange = (event) => {
    setQuantity(event.target.value);
  };

  const handleVendorSelectChange = (event) => {
    setSelectedVendor(event.target.value);
  };

  const handleAddClick = () => {
    if (selectedVendor && productName && quantity) {
      // Create a new order detail object with the selectedVendor property
      const newOrderDetail = { quantity, selectedVendor };
      // Add the new order detail to the orderDetails state
      setOrderDetails([...orderDetails, newOrderDetail]);
      // Create a new order object without the vendor property
      const newOrder = { product_name: productName };
      // Add the new order to the orders state
      setOrders([...orders, newOrder]);
      setProductName('');
      setQuantity('');
      setSelectedVendor('');
    } else {
      alert('Please select a vendor, enter a product name, and enter a quantity.');
    }
  };

  useEffect(() => {
    const fetchInventoryOrders = async () => {
      try {
        const inventoryResponse = await axios.get('http://localhost:5000/api/inventory_order');
        const inventoryOrders = inventoryResponse.data;
  
        const vendorResponse = await axios.get('http://localhost:5000/api/vendors');
        const vendors = vendorResponse.data;
  
        const updatedOrders = inventoryOrders.map(order => ({
          ...order,
          vendors
        }));
  
        setOrders(updatedOrders);
  
        // Initialize order details state with default values for each order
        const initialOrderDetails = updatedOrders.map(order => ({
          quantity: '', // Initialize quantity to empty string
          vendor: '' // Initialize selected vendor to empty string
        }));
        setOrderDetails(initialOrderDetails);
      } catch (error) {
        console.error('Error fetching inventory orders:', error);
      }
    };
  
    fetchInventoryOrders();
  }, []);
  const handleReturnOrderClick = () => {
    // Redirect to the desired page
    window.location.href = '/return';
  };
 
    return (
    <div>
      <div>
        <Adminheader />
         <Grid container justifyContent="flex-end" alignItems="center" style={{marginTop:'2%'}}>
           <Grid item style={{marginRight:'2%'}}>
            <Button variant="contained" onClick={handleReturnOrderClick}>Return</Button>
            
           </Grid>
        </Grid>
      </div>
    <Typography variant="h4">New Order</Typography>
      <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
        <div style={{ marginRight: '5%' }}>
          <label htmlFor="productName">Product Name:</label>
          <input
            type="text"
            id="productName"
            value={productName}
            onChange={handleProductNameChange}
            placeholder="Enter product name"
          />
        </div>
        <div style={{ marginRight: '5%' }}>
          <label htmlFor="quantity">Quantity:</label>
          <input
            type="number"
            id="quantity"
            value={quantity}
            onChange={handleQuantityInputChange}
            placeholder="Enter quantity"
          />
        </div>
        <div style={{ marginRight: '5%' }}>
          <label htmlFor="vendor">Vendor:</label>
          <select id="vendor" value={selectedVendor} onChange={handleVendorSelectChange} style={{ marginRight: '5%' }}>
            <option value="">Select a vendor</option>
            {vendorOptions.map((vendor) => (
              <option key={vendor.vendor_id} value={vendor.vendor_name}>
                {vendor.vendor_name}
              </option>
            ))}
          </select>
        </div>
        <Button variant="contained" onClick={handleAddClick}>Order</Button>
      </div>

      <div>
        <Typography variant="h5">List Of Pending Orders</Typography>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Product Name</TableCell>
              <TableCell>Quantity</TableCell>
              <TableCell>Vendor</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {orders.map((order, index) => (
              <TableRow key={index}>
                <TableCell>{order.product_name}</TableCell>
                <TableCell>
                  <TextField 
                    type="number" 
                    value={order.quantity} 
                    onChange={(e) => handleQuantityChange(index, e.target.value)} 
                  />
                </TableCell>
                <TableCell>
                <Select
  value={orderDetails[index] ? orderDetails[index].selectedVendor : ''}
  onChange={(e) => handleVendorChange(index, e.target.value)}
>
  <MenuItem value="">Select vendor</MenuItem>
  {order.vendors.map((vendor, vendorIndex) => (
    <MenuItem key={vendorIndex} value={vendor.vendor_name}>
      {vendor.vendor_name}
    </MenuItem>
  ))}
</Select>
            </TableCell>
              <TableCell>
                  <Button variant="contained" onClick={() => handleAddOrder(order.product_name, order.quantity, order.vendor)}>Order</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

      </div>
      
    </div>
  );
};

export default OrderManagement;
