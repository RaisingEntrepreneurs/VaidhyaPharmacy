import React from "react";

function About(){
    return(
        <p>ramu This application would the combination of Electronic medical record (EMR) systems, Pharmacy Inventory system, Billing and claims Management system</p>
    )
}
export default About