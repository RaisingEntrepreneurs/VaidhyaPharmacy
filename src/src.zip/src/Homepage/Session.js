// Session.js (Frontend)
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const useSessionValidity = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const checkSessionValidity = async () => {
      try {
        const sessionID = document.cookie
          .split(';')
          .find(cookie => cookie.trim().startsWith('sessionID='))
          ?.split('=')[1];
    
        if (!sessionID) {
          // Session ID not found, redirect to login page
          navigate('/home');
          return;
        }
    
        // Perform AJAX request to the server to check session validity
        const response = await axios.get(`http://127.0.0.1:5000/api/checkSession?sessionID=${sessionID}`);
        const data = response.data;
    
        if (!data.valid) {
          // Session is invalid, redirect to login page
          navigate('/home');
        }
      } catch (error) {
        console.error('Error checking session validity:', error);
      }
    };

    checkSessionValidity();
  }, [navigate]);

  return null; // You can return null or any other value here
};

export { useSessionValidity };
