// sessionService.js (Backend)

import { v4 as uuid } from 'uuid'; // Import uuid for session ID generation
// Simulated session data store (replace with actual data store)
const sessionStore = new Map();

// Function to generate a session token
function generateSessionToken(userID) {
  // Generate random data
  const randomData = Math.random().toString(36).substring(2) + Date.now().toString(36);

  // Combine with additional information (e.g., user ID)
  const combinedData = randomData + userID;

  // Encode the combined data (optional)
  const encodedToken = Buffer.from(combinedData).toString('base64');

  return encodedToken;
}



// Function to validate a session token
function validateSessionToken(sessionToken) {
  // Decode the session token if necessary (e.g., Base64 decoding)
  const decodedToken = Buffer.from(sessionToken, 'base64').toString('utf-8');

  // Extract information (e.g., user ID) from the decoded token
  const userID = decodedToken.substring(0, 6); // Example: Extract first 6 characters as user ID

  // Retrieve session data from the session store using the extracted information
  const storedSessionToken = sessionStore.get(userID);

  // Compare the received session token with the stored session token
  if (storedSessionToken === sessionToken) {
    // Session token is valid
    return true;
  } else {
    // Session token is invalid
    return false;
  }
}





const GenerateSession = async (user, navigate) => {
  try {
    // Generate session ID (You need to implement this)
    
    const sessionID = uuid();

    // Call the API endpoint to create a session
    const sessionResponse = await fetch('http://127.0.0.1:5000/api/checkSession', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionID: sessionID,
        userID: user.usrnme,
        username: user.usrnme,
        createdAt: new Date().toISOString() // Assuming the session creation time is current time
      })
    });

    // Check if session creation was successful
    const sessionData = await sessionResponse.json();
    if (sessionData.message === 'Session created successfully') {
      // Store the session ID in a cookie
      document.cookie = `sessionID=${sessionID}; path=/`;
    } else {
      console.log("Error creating session");
    }
  } catch (error) {
    console.error('Error generating session:', error);
  }
};

export { GenerateSession, generateSessionToken, validateSessionToken };
