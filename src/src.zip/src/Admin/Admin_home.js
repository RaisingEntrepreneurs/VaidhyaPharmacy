import React from "react";
import Adminheader from "./adminheader";

function AdminHome(){
    return(
<Adminheader></Adminheader>
    )
}
export default AdminHome;